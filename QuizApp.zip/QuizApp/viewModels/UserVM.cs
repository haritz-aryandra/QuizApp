﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QuizApp.viewModels
{
    public class UserVM { public int UserID { get; set; } public string FullName { get; set; } public string ProfilImage { get; set; } }

    public class QuizVM { public int QuizID { get; set; } public string QuizName { get; set; } public List<SelectListItem> ListofQuizz { get; set; } }

    public class QuestionVM { public int QuestionID { get; set; } public string QuestionText { get; set; } public string QuestionType { get; set; } public string Answer { get; set; } public ICollection<ChoiceVM> Choices { get; set; } }

    public class ChoiceVM { public int ChoiceID { get; set; } public string ChoiceText { get; set; } }

    public class QuizAnswersVM { public int QuestionID { get; set; } public string QuestionText { get; set; } public string AnswerQ { get; set; } public bool isCorrect { get; set; } }
}